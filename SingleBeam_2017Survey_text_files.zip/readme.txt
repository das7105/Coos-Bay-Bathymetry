
These data were collected in State Plane NAD83, Oregon South (meters). Depth measurements are referenced to the vertical datum NAVD88 (m). 

These files have all been processed with an estuary average speed of sound of 1483 m/s.

The filenames that include “samp” are where sediment samples were taken.